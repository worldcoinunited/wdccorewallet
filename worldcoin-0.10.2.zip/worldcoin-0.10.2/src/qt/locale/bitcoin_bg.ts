<TS language="bg" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Десен клик за промяна на адреса или името</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Създаване на нов адрес</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Нов</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Копиране на избрания адрес</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Копирай</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Затвори</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Копирай</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Изтрий избрания адрес от списъка</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Запишете данните от текущия раздел във файл</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>Изнеси</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Изтриване</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Изберете адрес, на който да се изпращат монети</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Изберете адрес за получаване на монети</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>Избери</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Адреси за изпращане</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Адреси за получаване</translation>
    </message>
    <message>
        <source>These are your Litecoin addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Това са адресите на получателите на плащания. Винаги проверявайте размера на сумата и адреса на получателя, преди да изпратите монети.</translation>
    </message>
    <message>
        <source>These are your Litecoin addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Това са Вашите Litecoin адреси,благодарение на които ще получавате плащания.Препоръчително е да използвате нови адреси за получаване за всяка транзакция.</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Копирай &amp;име</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редактирай</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Изнасяне на списъка с адреси</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV файл (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Грешка при изнасянето</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Възникна грешка при опита за запазване на списъка с адреси в %1.Моля опитайте отново.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(без име)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Диалог за паролите</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Въведи парола</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Нова парола</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Още веднъж</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Криптиране на портфейла</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Тази операция изисква Вашата парола за отключване на портфейла.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Отключване на портфейла</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Тази операция изисква Вашата парола за декриптиране на портфейла.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Декриптиране на портфейла</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Смяна на паролата</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Въведете текущата и новата парола за портфейла.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Потвърждаване на криптирането</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR LITECOINS&lt;/b&gt;!</source>
        <translation>ВНИМАНИЕ: Ако защитите вашият портфейл и изгубите ключовата дума, вие ще &lt;b&gt;ИЗГУБИТЕ ВСИЧКИТЕ СИ БИТКОЙНОВЕ&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Наистина ли искате да шифрирате портфейла?</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>ВАЖНО: Всякакви стари бекъп версии, които сте направили на вашият портфейл трябва да бъдат заменени със ново-генерирания, криптиран портфейл файл. От съображения за сигурност, предишните бекъпи на некриптираните портфейли ще станат неизползваеми веднага щом започнете да използвате новият криптиран портфейл.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Внимание: Caps Lock (главни букви) е включен.</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Портфейлът е криптиран</translation>
    </message>
    <message>
        <source>Litecoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your worldcoins from being stolen by malware infecting your computer.</source>
        <translation>Litecoin ще се затоври сега за да завърши процеса на криптиране. Запомнете, че криптирането на вашия портефейл не може напълно да предпази вашите Бит-монети от кражба чрез зловреден софтуер, инфектирал вашия компютър</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Криптирането беше неуспешно</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Криптирането на портфейла беше неуспешно поради неизвестен проблем. Портфейлът не е криптиран.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Паролите не съвпадат</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Отключването беше неуспешно</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Паролата въведена за декриптиране на портфейла е грешна.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Декриптирането беше неуспешно</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Паролата на портфейла беше променена успешно.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Подписване на &amp;съобщение...</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Синхронизиране с мрежата...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Баланс</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Сървър</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Обобщена информация за портфейла</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Трансакции</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>История на трансакциите</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Из&amp;ход</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Изход от приложението</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>За &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Покажи информация за Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Опции...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Криптиране на портфейла...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Запазване на портфейла...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Смяна на паролата...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Изпращане на адресите...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Получаване на адресите...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Отвори &amp;URI...</translation>
    </message>
    <message>
        <source>Litecoin Core client</source>
        <translation>Litecoin Core клиент</translation>
    </message>
    <message>
        <source>Send coins to a Litecoin address</source>
        <translation>Изпращане към Litecoin адрес</translation>
    </message>
    <message>
        <source>Modify configuration options for Litecoin</source>
        <translation>Променете настройките на Litecoin</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Запазване на портфейла на друго място</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Променя паролата за портфейла</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Прозорец за отстраняване на грешки</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Отворете конзолата за диагностика и отстраняване на грешки</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Проверка на съобщение...</translation>
    </message>
    <message>
        <source>Litecoin</source>
        <translation>Litecoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Портфейл</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Изпращане</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Получаване</translation>
    </message>
    <message>
        <source>Show information about Litecoin Core</source>
        <translation>Покажете информация за Litecoin ядрото</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Покажи / Скрий</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Показване и скриване на основния прозорец</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Шифроване на личните ключове,които принадлежат на портфейла Ви.</translation>
    </message>
    <message>
        <source>Sign messages with your Litecoin addresses to prove you own them</source>
        <translation>Пишете съобщения със своя Litecoin адрес за да докажете,че е ваш.</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Litecoin addresses</source>
        <translation>Потвърждаване на съобщения  за да се знае,че са написани с дадените Litecoin адреси.</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощ</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Раздели</translation>
    </message>
    <message>
        <source>Litecoin Core</source>
        <translation>Litecoin ядро</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and worldcoin: URIs)</source>
        <translation>Изискване на плащания(генерира QR кодове и worldcoin: URIs)</translation>
    </message>
    <message>
        <source>&amp;About Litecoin Core</source>
        <translation>&amp;Относно Litecoin Core</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Показване на списъка с използвани адреси и имена</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Покажи списък с използваните адреси и имена.</translation>
    </message>
    <message>
        <source>Open a worldcoin: URI or payment request</source>
        <translation>Отворете биткойн: URI  или заявка за плащане</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Налични команди</translation>
    </message>
    <message>
        <source>Show the Litecoin Core help message to get a list with possible Litecoin command-line options</source>
        <translation>Покажи помощните съобщения на Litecoin за да видиш наличните и валидни команди</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to Litecoin network</source>
        <translation><numerusform>%n връзка към Litecoin мрежата</numerusform><numerusform>%n връзки към Litecoin мрежата</numerusform></translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Липсва източник на блоковете...</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n час</numerusform><numerusform>%n часа</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n ден</numerusform><numerusform>%n дни</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n седмица</numerusform><numerusform>%n седмици</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n година</numerusform><numerusform>%n години</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 зад</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Транзакции след това няма все още да бъдат видими.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Данни</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Синхронизиран</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n blocks of transaction history.</source>
        <translation><numerusform>Обслужени %n блокове от историята с транзакции.</numerusform><numerusform>Обслужени %n блокове от историята с транзакции.</numerusform></translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Зарежда блокове...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Изходяща трансакция</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Входяща трансакция</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Дата: %1
Сума: %2
Вид: %3
Адрес: %4
</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Портфейлът е &lt;b&gt;криптиран&lt;/b&gt; и &lt;b&gt;отключен&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Портфейлът е &lt;b&gt;криптиран&lt;/b&gt; и &lt;b&gt;заключен&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Мрежови проблем</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Coin Selection</source>
        <translation>Избор на монета</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байтове:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Сума:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Такса:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Прах:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>След прилагане на ДДС</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Ресто</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>(Пре)махни всички</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Дървовиден режим</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Списъчен режим</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Получени с име</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Получени с адрес</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Потвърждения</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Потвърдени</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Копирай адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копирай име</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копирай сума</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копирай транзакция с ID</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Заключване на неизхарченото</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Отключване на неизхарченото</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копиране на количеството</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Копиране на данък добавена стойност</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Копиране след прилагане на данък добавена стойност</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Копиране на байтовете</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Копиране на приоритет</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Копирай прахта:</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Копирай рестото</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>Най-висок</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>По-висок</translation>
    </message>
    <message>
        <source>high</source>
        <translation>Висок</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>Средно-висок</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>Среден</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>Ниско-среден</translation>
    </message>
    <message>
        <source>low</source>
        <translation>Нисък</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>По-нисък</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>Най-нисък</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 заключен)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>нищо</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>да</translation>
    </message>
    <message>
        <source>no</source>
        <translation>не</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Това означава че се изисква такса от поне %1 на килобайт.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Може да варира с +-1 байт</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Това наименование се оцветява в червено, ако произволен получател получи сума по-малка от %1.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(без име)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>ресто от %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(промени)</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Редактиране на адрес</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Име</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Адрес</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Нов адрес за получаване</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Нов адрес за изпращане</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Редактиране на входящ адрес</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Редактиране на изходящ адрес</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Вече има адрес "%1" в списъка с адреси.</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid Litecoin address.</source>
        <translation>"%1" не е валиден Litecoin адрес.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Отключването на портфейла беше неуспешно.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Създаването на ключ беше неуспешно.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Ще се създаде нова папка за данни.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>име</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Директорията вече съществува.Добавете %1 ако желаете да добавите нова директория тук.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Пътят вече съществува и не е папка.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Не може да се създаде директория тук.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Litecoin Core</source>
        <translation>Litecoin ядро</translation>
    </message>
    <message>
        <source>version</source>
        <translation>версия</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-битов)</translation>
    </message>
    <message>
        <source>About Litecoin Core</source>
        <translation>За Litecoin Core</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Списък с команди</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Използване:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Списък с налични команди</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI Опции</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Задаване на език,например "de_DE" (по подразбиране: system locale)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Стартирай минимизирано</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Изберете директория при стартиране на програмата.( настройка по подразбиране:0)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Добре дошли</translation>
    </message>
    <message>
        <source>Welcome to Litecoin Core.</source>
        <translation>Добре дошли в Litecoin ядрото.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Litecoin Core will store its data.</source>
        <translation>Тъй като това е първото стартиране на програмата можете да изберете къде Litecoin ядрото да запази данните си.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Използване на директория по подразбиране</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Използване на директория ръчно</translation>
    </message>
    <message>
        <source>Litecoin Core</source>
        <translation>Litecoin ядро</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Отваряне на URI</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Основни</translation>
    </message>
    <message>
        <source>Automatically start Litecoin after logging in to the system.</source>
        <translation>Автоматично включване на Litecoin след влизане в системата.</translation>
    </message>
    <message>
        <source>&amp;Start Litecoin on system login</source>
        <translation>&amp;Пускане на Litecoin при вход в системата</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Размер на кеша в &amp;базата данни</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>Мегабайта</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Приемай връзки отвън</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Позволи входящите връзки</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP адрес на прокси (напр. за IPv4: 127.0.0.1 / за IPv6: ::1)</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>URL адреси на трети страни</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Възстановете всички настройки по подразбиране.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>&amp;Нулирай настройките</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Мрежа</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>По&amp;ртфейл</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Експерт</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Похарчете непотвърденото ресто</translation>
    </message>
    <message>
        <source>Automatically open the Litecoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Автоматично отваряне на входящия Litecoin порт. Работи само с рутери поддържащи UPnP.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Отваряне на входящия порт чрез &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the Litecoin network through a SOCKS5 proxy.</source>
        <translation>Свързване с Litecoin мрежата чрез SOCKS5  прокси.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Свързване чрез SOCKS5  прокси (прокси по подразбиране):</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Прокси &amp; АйПи:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Порт на прокси сървъра (пр. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Прозорец</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>След минимизиране ще е видима само иконата в системния трей.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Минимизиране в системния трей</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>При затваряне на прозореца приложението остава минимизирано. Ако изберете тази опция, приложението може да се затвори само чрез Изход в менюто.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>М&amp;инимизиране при затваряне</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Интерфейс</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Език:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting Litecoin.</source>
        <translation>Промяната на езика ще влезе в сила след рестартиране на Litecoin.</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Мерни единици:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Изберете единиците, показвани по подразбиране в интерфейса.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Дали да покаже възможностите за контрол на монетите или не.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>Отказ</translation>
    </message>
    <message>
        <source>default</source>
        <translation>подразбиране</translation>
    </message>
    <message>
        <source>none</source>
        <translation>нищо</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Потвърдете отмяната на настройките.</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Изисква се рестартиране на клиента за активиране на извършените промени.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Клиентът ще бъде изключен,искате ли да продължите?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Тази промяна изисква рестартиране на клиента Ви.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Прокси адресът е невалиден.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Litecoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Текущата информация на екрана може да не е актуална. Вашият портфейл ще се синхронизира автоматично с мрежата на Litecoin, щом поне една връзката с нея се установи; този процес все още не е приключил.</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>В наблюдателен режим:</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Налично:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Вашата текуща сметка за изразходване</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Изчакващо:</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Неразвит:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Миниран баланс,който все още не се е развил</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Баланс</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Общо:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Текущият ви общ баланс</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>За харчене:</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Скорошни транзакции</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>несинхронизиран</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>URI handling</source>
        <translation>Справяне с URI</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Невалиден адрес на плащане %1</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Заявката за плащане беше отхвърлена</translation>
    </message>
    <message>
        <source>Payment request network doesn't match client network.</source>
        <translation>Мрежата от която се извършва заявката за плащане не съвпада с мрежата на клиента.</translation>
    </message>
    <message>
        <source>Payment request has expired.</source>
        <translation>Заявката за плащане е изтекла.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Заявената сума за плащане: %1 е твърде малка (счита се за отпадък)</translation>
    </message>
    <message>
        <source>Payment request error</source>
        <translation>Възникна грешка по време назаявката за плащане</translation>
    </message>
    <message>
        <source>Cannot start worldcoin: click-to-pay handler</source>
        <translation>Биткойн не можe да се стартира: click-to-pay handler</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Файл за справяне със заявки</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Възстановяване на сума от %1</translation>
    </message>
    <message>
        <source>Payment request DoS protection</source>
        <translation>Дос защита на заявката за плащане</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Грешка при комуникацията с %1: %2</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Възникна проблем при свързването със сървър %1</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Плащането е прието</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>Грешка в мрежата по време на заявката</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>User Agent</source>
        <translation>Клиент на потребителя</translation>
    </message>
    <message>
        <source>Address/Hostname</source>
        <translation>Адрес в интернет</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Време за отговор</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>Enter a Litecoin address (e.g. %1)</source>
        <translation>Въведете Биткойн адрес (например: %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 ден</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 час</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 минута</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1 секунда</translation>
    </message>
    <message>
        <source>NETWORK</source>
        <translation>Мрежа</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>Неизвестен</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Неналичен</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>Несъществуващ</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 милисекунда</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Запиши изображение...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Копирай изображение</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>Запази QR Код</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG Изображение (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Client name</source>
        <translation>Име на клиента</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Версия на клиента</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>Данни</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>Прозорец с грешки</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Основни</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Използване на OpenSSL версия</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Използване на база данни BerkeleyDB </translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Време за стартиране</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Мрежа</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Брой връзки</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Текущ брой блокове</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Получени</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Изпратени</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Пиъри</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Избери пиър за детайлна информация.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Посока</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <source>User Agent</source>
        <translation>Клиент на потребителя</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Услуги</translation>
    </message>
    <message>
        <source>Starting Height</source>
        <translation>Стартова височина</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Продължителност на връзката</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Изпратени за последно</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Получени за последно</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>Изпратени байтове</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>Получени байтове</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Време за отговор</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Време на последния блок</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Отвори</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Конзола</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Мрежов Трафик</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Изчисти</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Общо:</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>Входящи:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>Изходящи</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Дата на създаване</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Лог файл,съдържащ грешките</translation>
    </message>
    <message>
        <source>Open the Litecoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Отворете Litecoin дебъг лог файла от настоящата Data папка. Може да отнеме няколко секунди при по - големи лог файлове.</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Изчисти конзолата</translation>
    </message>
    <message>
        <source>Welcome to the Litecoin RPC console.</source>
        <translation>Добре дошли в Litecoin RPC конзолата.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Използвайте стрелки надолу и нагореза разглеждане на историятаот команди и &lt;b&gt;Ctrl-L&lt;/b&gt; за изчистване на конзолата.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Въведeте &lt;/b&gt;помощ&lt;/b&gt; за да видите наличните команди.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 Байт</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 Килобайт</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 Мегабайт</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 Гигабайт</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>посредством %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>Никога</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Входящи</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Изходящи</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Неизвестен</translation>
    </message>
    <message>
        <source>Fetching...</source>
        <translation>Прихващане...</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Сума</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Име:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Съобщение:</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Използвате този формуляр за заявяване на плащания. Всички полета са &lt;b&gt;незадължителни&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Незадължително заявяване на сума. Оставете полето празно или нулево, за да не заявите конкретна сума.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Изчисти всички полета от формуляра.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Изчистване</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Изискана история на плащанията</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Изискване на плащане</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Показване</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Премахване</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копирай име</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Копиране на съобщението</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копирай сума</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR код</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>Копиране на &amp;URI</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Копирай адрес</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>&amp;Запиши изображение...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Изискване на плащане от %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Данни за плащането</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Грешка при създаването на QR Code от URI.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(без име)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(без съобщение)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(липсва сума)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Изпращане</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>Настройки за контрол на монетите</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>астоматично избран</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Нямате достатъчно налични пари!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байтове:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Сума:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Такса:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>След прилагане на ДДС</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Ресто</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Ако тази опция е активирана,но адресът на промяна е празен или невалиден,промяната ще бъде изпратена на новосъздаден адрес.</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Такса за транзакцията:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Избери...</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Минимизирай</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>за килобайт</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>Крайна сума поне</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Препоръчителна:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>По избор:</translation>
    </message>
    <message>
        <source>Confirmation time:</source>
        <translation>Време за потвърждение:</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>нормален</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>бърз</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Изпращане към повече от един получател</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Добави &amp;получател</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Изчисти всички полета от формуляра.</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Прах:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Изчисти</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Баланс:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Потвърдете изпращането</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>И&amp;зпрати</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Потвърждаване</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копиране на количеството</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копирай сума</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Копиране на данък добавена стойност</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Копиране след прилагане на данък добавена стойност</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Копиране на байтовете</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Копиране на приоритет</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Копирай рестото</translation>
    </message>
    <message>
        <source>Total Amount %1 (= %2)</source>
        <translation>Пълна сума %1 (= %2)</translation>
    </message>
    <message>
        <source>or</source>
        <translation>или</translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Невалиден адрес на получателя.</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Сумата трябва да е по-голяма от 0.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Сумата надвишава текущия баланс</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Сумата при добавяне на данък добавена стойност по %1 транзакцията надвишава сумата по вашата сметка.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Грешка при създаването на транзакция!</translation>
    </message>
    <message>
        <source>A fee higher than %1 is considered an insanely high fee.</source>
        <translation>Такса по-висока от %1 се смята за извънредно висока.</translation>
    </message>
    <message>
        <source>Pay only the minimum fee of %1</source>
        <translation>Платете минималната такса от %1</translation>
    </message>
    <message>
        <source>Warning: Invalid Litecoin address</source>
        <translation>Внимание: Невалиден Litecoin адрес</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(без име)</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Внимание:Неизвестен адрес за промяна</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Копирай прахта:</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Наистина ли искате да изпратите?</translation>
    </message>
    <message>
        <source>added as transaction fee</source>
        <translation>добавено като такса за трансакция</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>С&amp;ума:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Плати &amp;На:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Въведете име за този адрес, за да го добавите в списъка с адреси</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Име:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Изберете използван преди адрес</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>Това е нормално плащане.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вмъкни от клипборда</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Премахване на този запис</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Съобщение:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Това е потвърдена транзакция.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Това е непотвърдена заявка за плащане.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Плащане на:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Бележка:</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Litecoin Core is shutting down...</source>
        <translation>Litecoin ядрото се изключва...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Не изключвайте компютъра докато този прозорец не изчезне.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Подпиши / Провери съобщение</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Подпиши</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Можете да подпишете съобщение като доказателство, че притежавате определен адрес. Бъдете внимателни и не подписвайте съобщения, които биха разкрили лична информация без вашето съгласие.</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Изберете използван преди адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вмъкни от клипборда</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Въведете съобщението тук</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Подпис</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Копиране на текущия подпис</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Litecoin address</source>
        <translation>Подпишете съобщение като доказателство, че притежавате определен адрес</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Подпиши &amp;съобщение</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Изчисти</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Провери</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Litecoin address</source>
        <translation>Проверете съобщение, за да сте сигурни че е подписано с определен Litecoin адрес</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Потвърди &amp;съобщението</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>Натиснете "Подписване на съобщение" за да създадете подпис</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Въведеният адрес е невалиден.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Моля проверете адреса и опитайте отново.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Въведеният адрес не може да се съпостави с валиден ключ.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Отключването на портфейла беше отменено.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Не е наличен частният ключ за въведеният адрес.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Подписването на съобщение бе неуспешно.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Съобщението е подписано.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Подписът не може да бъде декодиран.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Проверете подписа и опитайте отново.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Подписът не отговаря на комбинацията от съобщение и адрес.</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Проверката на съобщението беше неуспешна.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Съобщението е потвърдено.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Litecoin Core</source>
        <translation>Litecoin ядро</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>Разработчици на Bitcoin Core</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>Килобайта в секунда</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Подлежи на промяна до %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>припокриващ се</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/офлайн</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/непотвърдени</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>включена в %1 блока</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Статус</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Източник</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Издадени</translation>
    </message>
    <message>
        <source>From</source>
        <translation>От</translation>
    </message>
    <message>
        <source>To</source>
        <translation>За</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>собствен адрес</translation>
    </message>
    <message>
        <source>label</source>
        <translation>име</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Кредит</translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>не е приет</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Дебит</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Такса</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Сума нето</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Съобщение</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Коментар</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Търговец</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Информация за грешките</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Трансакция</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сума</translation>
    </message>
    <message>
        <source>true</source>
        <translation>true</translation>
    </message>
    <message>
        <source>false</source>
        <translation>false</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, все още не е изпратено</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>неизвестен</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Трансакция</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Описание на трансакцията</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Подлежи на промяна до %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Потвърдени (%1 потвърждения)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Блокът не е получен от останалите участници и най-вероятно няма да бъде одобрен.</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Генерирана, но отхвърлена от мрежата</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Извън линия</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Непотвърдено</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Потвърждаване (%1 от %2 препоръчвани потвърждения)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>Конфликтно</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Получени с</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Получен от</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Изпратени на</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Плащане към себе си</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Емитирани</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Състояние на трансакцията. Задръжте върху това поле за брой потвърждения.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Дата и час на получаване.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Вид трансакция.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Получател на трансакцията.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Сума извадена или добавена към баланса.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Всички</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Днес</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Тази седмица</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Този месец</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Предния месец</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Тази година</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>От - до...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Получени</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Изпратени на</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Собствени</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Емитирани</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Други</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Търсене по адрес или име</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Минимална сума</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Копирай адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копирай име</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копирай сума</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копирай транзакция с ID</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Редактирай име</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Подробности за трансакцията</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Изнасяне историята на трансакциите</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Грешка при изнасянето</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Изнасянето е успешна</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Историята с транзакциите беше успешно запазена в %1.</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>CSV файл (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Потвърдени</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Име</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ИД</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>От:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>до</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Няма зареден портфейл.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Изпращане</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>Изнеси</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Запишете данните от текущия раздел във файл</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Запазване на портфейла</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Информация за портфейла (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Неуспешно запазване на портфейла</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Възникна грешка при запазването на информацията за портфейла в %1.</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Информацията за портфейла беше успешно запазена в %1.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Успешно запазване на портфейла</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Опции:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Определете директория за данните</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Свържете се към сървър за да можете да извлечете адресите на пиърите след което се разкачете.</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Въведете Ваш публичен адрес</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Използвайте тестовата мрежа</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Приемайте връзки отвън.(по подразбиране:1 в противен случай -proxy или -connect)</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Внимание: -paytxfee има голяма стойност! Това е таксата за транзакциите, която ще платите ако направите транзакция.</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given netmask or IP address. Can be specified multiple times.</source>
        <translation>Сложете в бял списък пиъри,свързващи се от дадената интернет маска или айпи адрес.Може да бъде заложено неколкократно.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(по подразбиране 1)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; може да бъде:</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Настройки на връзката:</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Желаете ли да пресъздадете базата данни с блокове сега?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Грешка в пускането на базата данни с блокове</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Грешка: мястото на диска е малко!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Провалено "слушане" на всеки порт. Използвайте -listen=0 ако искате това.</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Внасяне...</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Проверка на блоковете...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Проверка на портфейла...</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Настройки на портфейла:</translation>
    </message>
    <message>
        <source>Set the number of threads for coin generation if enabled (-1 = all cores, default: %d)</source>
        <translation>Заложете броя на нишки за генерация на монети ако е включено(-1 = всички ядра, по подразбиране: %d)</translation>
    </message>
    <message>
        <source>Warning: -maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>Внимание: -maxtxfee има много висока стойност! Толкова високи такси могат да бъдат заплатени на една транзакция.</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Свързване чрез SOCKS5  прокси</translation>
    </message>
    <message>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation>Всички права запазени (C) 2009-%i Доставчиците на Биткойн</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Данни</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Невалидна сума за -minrelaytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>Невалидна сума за -mintxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Изпрати локализиращата или дебъг информацията към конзолата, вместо файлът debug.log</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Това е експериментален софтуер.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Сумата на трансакцията е твърде малка</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Сумите на трансакциите трябва да са положителни</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Трансакцията е твърде голяма</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Потребителско име за JSON-RPC връзките</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Внимание: Използвате остаряла версия, необходимо е обновление!</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>по време на стартирането</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Парола за  JSON-RPC връзките</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Обновяване на портфейла до най-новия формат</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Повторно сканиране на блок-връзка за липсващи портфейлни трансакции</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Използвайте OpenSSL (https) за JSON-RPC връзките</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Това помощно съобщение</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Зареждане на адресите...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Грешка при зареждане на wallet.dat: портфейлът е повреден</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Грешка при зареждане на wallet.dat</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Невалиден -proxy address: '%s'</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Назовете конфигурационен файл(по подразбиране %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Задайте време на изключване при проблеми със свързването в милисекунди(минимум:1, по подразбиране %d)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>Задайте pid  файл(по подразбиране: %s)</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Невалидна сума за -paytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Недостатъчно средства</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Зареждане на блок индекса...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Зареждане на портфейла...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Преразглеждане на последовтелността от блокове...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Зареждането е завършено</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Грешка</translation>
    </message>
</context>
</TS>
